export class Company {
    name: string;
    catchPhrase: string;
    bs: string;
}